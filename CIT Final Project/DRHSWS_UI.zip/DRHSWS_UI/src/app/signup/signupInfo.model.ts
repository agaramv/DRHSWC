export class SignupInfo{
    date: string;
    day: string;
    lunch: string;

    constructor(date: string, day: string, lunch: string){
        this.date = date;
        this.day = day;
        this.lunch = lunch;
    }
}
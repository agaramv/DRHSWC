jQuery(function () {
    //jquery code here
})